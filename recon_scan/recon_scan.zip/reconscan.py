#!/usr/bin/env python

# [Title]: reconscan.py -- a recon/enumeration script
# [Author]: Mike Czumak (T_v3rn1x) -- @SecuritySift
#
# [Details]:
# This script is intended to be executed remotely against a list of IPs to enumerate discovered services such
# as smb, smtp, snmp, ftp and other.
#
# [Warning]:
# This script comes as-is with no promise of functionality or accuracy.  I strictly wrote it for personal use
# I have no plans to maintain updates, I did not write it to be efficient and in some cases you may find the
# functions may not produce the desired results so use at your own risk/discretion. I wrote this script to
# target machines in a lab environment so please only use it against systems for which you have permission!!
#
# [Modification, Distribution, and Attribution]:
# You are free to modify and/or distribute this script as you wish.  I only ask that you maintain original
# author attribution and not attempt to sell it or incorporate it into any commercial offering (as if it's
# worth anything anyway :)

import argparse
import multiprocessing
import os
import subprocess
from multiprocessing import Process


def multi_proc(process, ip_address, port, save_file_path=None, fuzzdb_path=None, usernames=None,
               passwords=None):
    jobs = []
    p = multiprocessing.Process(target=process, args=(ip_address, port, save_file_path, fuzzdb_path, usernames,
                                                      passwords))
    jobs.append(p)
    p.start()
    return


def dns_enum(ip_address, port):
    print("INFO: Detected DNS on {ip}:{port}".format(ip=ip_address, port=port))
    if port.strip() == "53":
        script = "./dnsrecon.py {ip}".format(ip=ip_address)  # execute the python script
        subprocess.call(script, shell=True)
    return


def http_enum(ip_address, port, save_file_path):
    print("INFO: Detected http on {ip}:{port}".format(ip=ip_address, port=port))
    print("INFO: Performing nmap web script scan for {ip}:{port}".format(ip=ip_address, port=port))
    http_scan = "nmap -sV -Pn -vv -p {port} --script=http-vhosts,http-userdir-enum,http-apache-negotiation," \
                "http-backup-finder,http-config-backup,http-default-accounts,http-email-harvest,http-methods," \
                "http-method-tamper,http-passwd,http-robots.txt -oN " \
                "{save_file}_http.nmap {ip}".format(port=port, ip=ip_address, save_file=save_file_path)
    subprocess.check_output(http_scan, shell=True)
    dir_bust = "./dirbust.py http://{ip}:{port} {ip} {save_file_path}".format(ip=ip_address, port=port,
                                                                              save_file_path=save_file_path)
    subprocess.check_output(dir_bust, shell=True)


def https_enum(ip_address, port, save_file_path):
    print("INFO: Detected http on {ip}:{port}".format(ip=ip_address, port=port))
    print("INFO: Performing nmap web script scan for {ip}:{port}".format(ip=ip_address, port=port))
    https_scan = "nmap -sV -Pn -vv -p {port} --script=http-vhosts,http-userdir-enum,http-apache-negotiation," \
                 "http-backup-finder,http-config-backup,http-default-accounts,http-email-harvest,http-methods," \
                 "http-method-tamper,http-passwd,http-robots.txt -oX " \
                 "{save_file}_https.nmap {ip}".format(port=port, ip=ip_address, save_file=save_file_path)
    subprocess.check_output(https_scan, shell=True)
    dir_bust = "./dirbust.py https://{ip}:{port} {ip} {save_file_path}".format(ip=ip_address, port=port,
                                                                               save_file_path=save_file_path)
    subprocess.check_output(dir_bust, shell=True)


def mssql_enum(ip_address, port, save_file_path):
    print("INFO: Detected MS-SQL on {ip}:{port}".format(ip=ip_address, port=port))
    print("INFO: Performing nmap mssql script scan for {ip}:{port}".format(ip=ip_address, port=port))
    mssql_scan = "nmap -vv -sV -Pn -p {port} --script=ms-sql-info,ms-sql-config,ms-sql-dump-hashes " \
                 "--script-args=mssql.instance-port=1433,smsql.username-sa,mssql.password-sa -oX " \
                 "{save_file}_mssql.xml {ip}".format(port=port, ip=ip_address, save_file=save_file_path)
    subprocess.check_output(mssql_scan, shell=True)


def ssh_enum(ip_address, port, wordlist_path, save_file_path):
    print("INFO: Detected SSH on {ip}:{port}".format(ip=ip_address, port=port))
    script = "./sshrecon.py {ip} {port} {wordlist_path} {save_file_path}".format(ip=ip_address, port=port,
                                                                                 wordlist_path=wordlist_path,
                                                                                 save_file_path=save_file_path)
    subprocess.check_output(script, shell=True)


def snmp_enum(ip_address, port):
    print("INFO: Detected snmp on {ip}:{port}".format(ip=ip_address, port=port))
    script = "./snmprecon.py {ip}".format(ip=ip_address)
    subprocess.check_output(script, shell=True)


def smtp_enum(ip_address, port, fuzzdb_path):
    print("INFO: Detected smtp on {ip}:{port}".format(ip=ip_address, port=port))
    if port.strip() == "25":
        script = "./smtprecon.py {ip} {fuzzdb_path}".format(ip=ip_address, fuzzdb_path=fuzzdb_path)
        subprocess.check_output(script, shell=True)
    else:
        print("WARNING: SMTP detected on non-standard port, smtprecon skipped (must run manually)")


def smb_enum(ip_address, port):
    print("INFO: Detected SMB on {ip}:{port}".format(ip=ip_address, port=port))
    if port.strip() == "445":
        script = "./smbrecon.py {ip} 2>/dev/null".format(ip=ip_address)
        subprocess.call(script, shell=True)
    else:
        print("WARNING: SMB detected on non-standard port, smbrecon skipped (must run manually)")


def ftp_enum(ip_address, port, save_file_path, usernames, passwords):
    print("INFO: Detected ftp on {ip}:{port}".format(ip=ip_address, port=port))
    script = "./ftprecon.py {ip} {port} {save_file_path} {usernames_list} {password_list}".format(ip=ip_address,
                                                                                                  port=port,
                                                                                                  save_file_path=
                                                                                                  save_file_path,
                                                                                                  usernames_list=
                                                                                                  usernames,
                                                                                                  password_list=
                                                                                                  passwords)
    subprocess.call(script, shell=True)


def nmap_scan(ip_address, log_dir, fuzzdb_path, usernames, passwords):
    ip_address = ip_address.strip()
    save_file_path = os.path.join(log_dir, ip_address)
    print("INFO: Running general TCP/UDP nmap scans for {ip}".format(ip=ip_address))
    serv_dict = {}
    tcp_scan = "nmap -vv -Pn -A -sC -sS -T 4 -p- -oN '{save_file_path}.nmap' " \
               "-oX '{save_file_path}_nmap_scan_import.xml' {ip}".format(save_file_path=save_file_path, ip=ip_address)
    udp_scan = "nmap -vv -Pn -A -sC -sU -T 4 --top-ports 200 -oN '{save_file_path}U.nmap' " \
               "-oX '{save_file_path}U_nmap_scan_import.xml' {ip}".format(save_file_path=save_file_path, ip=ip_address)
    results = subprocess.check_output(tcp_scan, shell=True)
    udp_results = subprocess.check_output(udp_scan, shell=True)
    lines = results.split("\n")
    for line in lines:
        ports = []
        line = line.strip()
        if ("tcp" in line) and ("open" in line) and not ("Discovered" in line):
            while "  " in line:
                line = line.replace("  ", " ");
            linesplit = line.split(" ")
            service = linesplit[2]  # grab the service name
            port = line.split(" ")[0]  # grab the port/proto
            if service in serv_dict:
                ports = serv_dict[service]  # if the service is already in the dict, grab the port list

            ports.append(port)
            serv_dict[service] = ports  # add service to the dictionary along with the associated port(2)

    # go through the service dictionary to call additional targeted enumeration functions
    for serv in serv_dict:
        ports = serv_dict[serv]
        if serv == "http":
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=http_enum, ip_address=ip_address, port=port, save_file_path=save_file_path)
        elif (serv == "ssl/http") or ("https" in serv):
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=https_enum, ip_address=ip_address, port=port, save_file_path=save_file_path)
        elif "ssh" in serv:
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=ssh_enum, ip_address=ip_address, port=port, save_file_path=save_file_path,
                           usernames=usernames, passwords=passwords)
        elif "smtp" in serv:
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=smtp_enum, ip_address=ip_address, port=port, save_file_path=save_file_path,
                           fuzzdb_path=fuzzdb_path)
        elif "snmp" in serv:
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=snmp_enum, ip_address=ip_address, port=port, save_file_path=save_file_path)
        elif "domain" in serv:
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=dns_enum, ip_address=ip_address, port=port, save_file_path=save_file_path)
        elif "ftp" in serv:
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=ftp_enum, ip_address=ip_address, port=port, save_file_path=save_file_path,
                           usernames=usernames, passwords=passwords)
        elif "microsoft-ds" in serv:
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=smb_enum, ip_address=ip_address, port=port)
        elif "ms-sql" in serv:
            for port in ports:
                port = port.split("/")[0]
                multi_proc(process=mssql_enum, ip_address=ip_address, port=port, save_file_path=save_file_path)

    exit("INFO: TCP/UDP Nmap scans completed for {ip}".format(ip=ip_address))


# grab the discover scan results and start scanning up hosts
print("############################################################")
print("####                      RECON SCAN                    ####")
print("####            A multi-process service scanner         ####")
print("####        http, ftp, dns, ssh, snmp, smtp, ms-sql     ####")
print("############################################################")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    ips = parser.add_mutually_exclusive_group(required=True)
    ips.add_argument('--ips', help='IPs to Scan')
    ips.add_argument('--ip_file', help='File containing a list of IPs to scan.')
    parser.add_argument('--log_dir', help="Directory to store results.", default="/tmp")
    parser.add_argument('--fuzzdb_path', help="Path to FuzzDB Wordlists",
                        default='/usr/share/wfuzz/wordlist/fuzzdb')
    parser.add_argument('--usernames', help="Username wordlists",
                        default="/usr/share/wfuzz/wordlist/fuzzdb/wordlists-user-passwd/names/namelist.txt")
    parser.add_argument('--passwords', help="Password wordlists",
                        default="/usr/share/wfuzz/wordlist/fuzzdb/wordlists-user-passwd/names/namelist.txt")
    args = parser.parse_args()

    if args.ip:
        if "," in args.ip:
            ips = [ip.strip() for ip in args.ip.split(',')]
        else:
            ips = [ip.strip() for ip in args.ip.split(' ')]
    elif args.ip_file:
        ips = open(args.ip_file, 'r')

    for scan_ip in ips:
        jobs = []
        p = multiprocessing.Process(target=nmap_scan, args=(scan_ip, args.log_dir, args.fuzzdb_path, args.usernames,
                                                            args.passwords))
        jobs.append(p)
        p.start()
