import sys
import subprocess


def smb_recon(ip_address):
    nbt_scan = "./samrdump.py {ip}".format(ip=ip_address)
    nbtresults = subprocess.check_output(nbt_scan, shell=True)
    if ("Connection refused" not in nbtresults) and ("Connect error" not in nbtresults) and (
                "Connection reset" not in nbtresults):
        print("[*] SAMRDUMP User accounts/domains found on {ip}".format(ip=ip_address))
        lines = nbtresults.split(b"\n")
        for line in lines:
            if ("Found" in line) or (" . " in line):
                print("   [+] {line}".format(line=line))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: smbrecon.py <ip address>")
        sys.exit(0)
    smb_recon(ip_address=sys.argv[1])
